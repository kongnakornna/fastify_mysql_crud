export default {
  properties: {
    'state': {
      type: 'string'
    },
    authorization: {
      type: 'string'
    }
  },
  required: ['state']
}