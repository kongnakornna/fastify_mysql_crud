import * as knex from 'knex';
/**************************************************/    
export class AdministratorModel {
create(db1: knex, data: any) {
    return db1('ad_administrator')
      .insert(data)
  }
lastidread(db1: knex) {
    return db1('ad_administrator')
      .select('user_id')
      .orderBy('id','desc')
      .limit(1)
  }
updateuid(db1: knex, userId: any, data: any) {
    return db1('ad_administrator')
      .where('id', userId)
      .update(data)
  }
validation_email(db1: knex, email: any) {
    return db1('ad_administrator')
      .select('email')
      .where('email', email)
    }
validation_username(db1: knex, username: any) {
    return db1('ad_administrator')
      .select('username')
      .where('username', username)
    }
validation_network_id(db1: knex, network_id: any) {
    return db1('ad_administrator')
      .select('network_id')
      .where('network_id', network_id)
    }
where_ad_administrator_profile_id(db1: knex, ad_administrator_profile_id: any) {
        return db1('ad_administrator')
            .select('id', 'email')
            .select('username', 'role_id', 'status', 'network_id')
            .select('date')
        .where('ad_administrator_profile_id', ad_administrator_profile_id)
    }
where_user_update_password(db1: knex, username: any, data: any) {
        return db1('ad_administrator')
        .where('username', username)
        .update(data)
    }
where_ad_administrator_profile_id_update(db1: knex, ad_administrator_profile_id: any, data: any) {
        return db1('ad_administrator')
        .where('ad_administrator_profile_id', ad_administrator_profile_id)
        .update(data)
    }
where_ad_administrator_profile_id_remove(db1: knex, ad_administrator_profile_id: any) {
        return db1('ad_administrator')
        .where('ad_administrator_profile_id', ad_administrator_profile_id)
        .del()
    }
ad_administrator_profile(db1: knex, user_id: any) {
    return db1('ad_administrator')
      .select('id', 'email', 'username', 'role_id', 'status', 'network_id')
      .where('id', user_id)
   }
login(db1: knex, username: any, password: any) {
    return db1('ad_administrator')
      .select('id', 'email', 'username', 'role_id')
      .where('username', username)
      .where('password', password)
      .where('status', 1)
  }
resetPassword(db1: knex, datareset: any) {
    return db1('ad_administrator')
      .select('id', 'firstname', 'lastname')
      .select('email', 'username', 'role_id')
      .where('username', datareset)
      .orWhere('email', datareset)
    }
resetpwd(db1: knex, datareset: any) {
    return db1('ad_administrator')
      .select('id', 'email', 'username', 'role_id')
      .where('username', datareset)
      .orWhere('email', datareset)
  }
read(db1: knex) {
    return db1('ad_administrator')
      .select('id', 'email')
      .orderBy('id','desc')
      //.limit(3)
      // .offset(5)
      
  }
search(db1: knex, query: any) {
    const _query = '%' + query + '%'
    return db1('ad_administrator')
      .select('id', 'email')
      .where('firstname', 'like', _query)
      .orderBy('user_id')
  }
update(db1: knex, userId: any, data: any) {
    return db1('ad_administrator')
      .where('id', userId)
      .update(data)
  }
remove(db1: knex, userId: any) {
    return db1('ad_administrator')
      .where('id', userId)
      .del()
  }
// Raw query
rawQuery(db1: knex, userId: any, firstName: any) {
    const sql = `
    SELECT user_id, firstname, lastname,email
    FROM users
    WHERE user_id=? AND firstname=?
    ORDER BY firstname DESC
    `
    return db1.raw(sql, [userId, firstName])
  }
test(db1: knex) {
       const rt = db1('ad_administrator as u')
            .leftJoin('ad_administrator_profile as p', 'u.user_id', 'p.user_id')
            // .select('u.*')
            .select('u.user_id', 'u.firstname', 'u.lastname', 'u.email', 'u.date')
            .select('p.*')
            // .where('users.user_id!=','')
            .orderBy('u.user_id', 'desc')
            .limit(3)
            .offset(5)
        
        return rt
    }
whereRawQuery(db1: knex) {
    return db1('ad_administrator')
      .select('*')
      .whereRaw('group')
  }
/**************************************************/
/** ad_administrator_roles **/

}