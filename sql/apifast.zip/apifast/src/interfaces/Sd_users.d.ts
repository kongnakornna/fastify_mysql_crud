export interface Sd_users_model {
  id: number
  firstName: string
  lastName: string
  age: number
}
