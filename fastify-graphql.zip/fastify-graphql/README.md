## typescript-fastify-graphql-boilerplate

A Fastify GraphQL Server boilerplate built with Apollo-Server, TypeORM, Type-GraphqQL.
